#!/bin/bash
echo "Hola, $USER, la fecha actual es $(date)"
